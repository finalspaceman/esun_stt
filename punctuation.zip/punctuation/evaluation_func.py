from collections import namedtuple, defaultdict
from copy import deepcopy
import itertools
import re

import numpy as np
from esun_phoneme_tool.tokenizer import Tokenizer
from esun_phoneme_tool.phonizer import Phonizer

from utils import wordize_and_map


def extract_punctuation_map(sentences, punctuations):
    # e.g. "我是誰？請問你。"
    #   return ('我是誰請問你', {2: ['？'], 5: ['。']})
    # e.g. "這是你的嗎！？"
    #   return ('這是你的嗎', {4: ['！', '？']})

    punct_maps = []
    sentence_without_punctuations = []

    for sentence in sentences:
        sentence_without_punctuation = ''
        punct_map = defaultdict(list)
        for char in sentence:
            if char in punctuations:
                punct_map[len(sentence_without_punctuation) - 1].append(char)
            else:
                sentence_without_punctuation += char
        punct_maps.append(punct_map)
        sentence_without_punctuations.append(sentence_without_punctuation)

    return punct_maps, sentence_without_punctuations


def calculate_f1(true_punctuation_map, pred_punctuation_map, punctuations):
    # precision = true_pos / (true_pos + false_pos)
    # recall = true_pos / (true_pos + false_neg)
    # f1 = 2 / (1 / precision + 1 / recall)
    positions = sorted(
        list(set(true_punctuation_map.keys()).union(set(pred_punctuation_map.keys()))))

    true_pos = defaultdict(lambda: 0)
    false_pos = defaultdict(lambda: 0)
    false_neg = defaultdict(lambda: 0)
    for i in positions:
        if i in true_punctuation_map and i in pred_punctuation_map:
            punct_true = true_punctuation_map[i]
            punct_pred = pred_punctuation_map[i]

            matching_len = 0
            for ele_true, ele_pred in zip(punct_true, punct_pred):
                if ele_true != ele_pred:
                    break
                matching_len += 1

            for punct in punct_true[:matching_len]:
                true_pos[punct] += 1
            if len(punct_true) > matching_len:
                for punct in punct_true[matching_len:]:
                    false_neg[punct] += 1
            if len(punct_pred) > matching_len:
                for punct in punct_pred[matching_len:]:
                    false_pos[punct] += 1
        elif i in true_punctuation_map:
            for punct in true_punctuation_map[i]:
                false_neg[punct] += 1
        elif i in pred_punctuation_map:
            for punct in pred_punctuation_map[i]:
                false_pos[punct] += 1

    precision = {}
    recall = {}
    f1 = {}
    for punct in punctuations:
        try:
            precision[punct] = true_pos[punct] / \
                (true_pos[punct] + false_pos[punct])
        except ZeroDivisionError:
            precision[punct] = None

        try:
            recall[punct] = true_pos[punct] / \
                (true_pos[punct] + false_neg[punct])
        except ZeroDivisionError:
            recall[punct] = None

        try:
            f1[punct] = 2 / (1 / precision[punct] + 1 / recall[punct]) \
                if precision[punct] and recall[punct] else None
        except ZeroDivisionError:
            f1[punct] = None
    return precision, recall, f1


def _convert_to_bopomofo(word_lst):
    word_lst = deepcopy(word_lst)
    en_num_rule = r'^[a-zA-Z0-9]+'
    tokenizer = Tokenizer()
    phonizer = Phonizer()

    def _convert_segment(segment):
        tokens, _ = tokenizer.tokenize(segment)
        token_bopomofo = [phonizer.bopomofo_phonize(token) for token in tokens]
        token_bopomofo = list(itertools.chain(*token_bopomofo))
        return token_bopomofo

    output_lst = []
    segment = ''
    while word_lst:
        word = word_lst.pop(0)
        if re.match(en_num_rule, word):     # if last word is english or number
            token_bopomofo = _convert_segment(segment)
            output_lst += token_bopomofo + [word]
            segment = ''
        else:
            segment += word
    token_bopomofo = _convert_segment(segment)    # end of convert
    output_lst += token_bopomofo

    return output_lst


def remove_mark(word_lst):
    ch_en_num_rule = r'[a-zA-Z0-9\u4e00-\u9fa5\u3105-\u3129\u02CA\u02C7\u02CB\u02D9\s]'
    removed_word_list = []
    for word in word_lst:
        if re.match(ch_en_num_rule, word):
            removed_word_list.append(word)
    return removed_word_list


def english_upper(word_lst):
    return [word.upper() for word in word_lst]


def _create_opt_and_cost_matrix(ref_lst, hyp_lst):
    len_ref = len(ref_lst)
    len_hyp = len(hyp_lst)
    cost_matrix = np.zeros((len_hyp+1, len_ref+1), dtype=np.int16)
    operation_matrix = np.zeros((len_hyp, len_ref), dtype=np.int8)
    for ref_idx in range(len_ref+1):
        cost_matrix[0][ref_idx] = ref_idx
    for hyp_idx in range(len_hyp+1):
        cost_matrix[hyp_idx][0] = hyp_idx
    for hyp_idx in range(len_hyp):
        for ref_idx in range(len_ref):
            if ref_lst[ref_idx] == hyp_lst[hyp_idx]:
                cost_matrix[hyp_idx+1][ref_idx +
                                       1] = cost_matrix[hyp_idx][ref_idx]
            else:
                substitution = cost_matrix[hyp_idx][ref_idx] + 1
                insertion = cost_matrix[hyp_idx][ref_idx+1] + 1
                deletion = cost_matrix[hyp_idx+1][ref_idx] + 1
                operation_lst = [substitution, insertion, deletion]
                min_cost_val = min(operation_lst)
                operation_idx = operation_lst.index(min_cost_val) + 1
                cost_matrix[hyp_idx+1][ref_idx+1] = min_cost_val
                operation_matrix[hyp_idx][ref_idx] = operation_idx
    return operation_matrix, cost_matrix


def editops(ref_lst, hyp_lst):
    ref_lst, hyp_lst = deepcopy(ref_lst), deepcopy(hyp_lst)
    operation_matrix, _ = _create_opt_and_cost_matrix(ref_lst, hyp_lst)
    executions = []
    ref_idx, hyp_idx = len(ref_lst)-1, len(hyp_lst)-1
    # ------------ decode from back ------------
    while (ref_idx >= 0) | (hyp_idx >= 0):
        if (ref_idx >= 0) & (hyp_idx >= 0):
            if operation_matrix[hyp_idx][ref_idx] == 0:
                ref_idx -= 1
                hyp_idx -= 1
            elif operation_matrix[hyp_idx][ref_idx] == 1:
                executions.append(
                    (ref_idx, 'subsitute', ref_lst[ref_idx], hyp_lst[hyp_idx]))
                ref_idx -= 1
                hyp_idx -= 1
            elif operation_matrix[hyp_idx][ref_idx] == 2:
                executions.append(
                    (ref_idx+1, 'insertion', ref_lst[ref_idx], hyp_lst[hyp_idx]))
                hyp_idx -= 1
            elif operation_matrix[hyp_idx][ref_idx] == 3:
                executions.append(
                    (ref_idx, 'deletion', ref_lst[ref_idx], hyp_lst[hyp_idx]))
                ref_idx -= 1
        # ------------ 邊界處理 ------------
        elif (ref_idx < 0):
            executions.append((0, 'insertion', None, hyp_lst[hyp_idx]))
            hyp_idx -= 1
        elif (hyp_idx < 0):
            executions.append((ref_idx, 'deletion', ref_lst[ref_idx], None))
            ref_idx -= 1
    executions = _trans_trace_from_start(executions)
    return executions


def _trans_trace_from_start(executions):
    adj_num = 0
    adj_executions = []
    for idx, exe, ref, hyp in executions[::-1]:
        idx += adj_num
        if exe == 'insertion':
            adj_num += 1
        elif exe == 'deletion':
            adj_num -= 1
        adj_executions.append((idx, exe, ref, hyp))
    return adj_executions


def calculate_cer(ref, hyp, exec_detail=True, bopomofo=False):
    ref, hyp = deepcopy(ref), deepcopy(hyp)
    if isinstance(ref, str):
        ref_word_lst, _, _ = wordize_and_map(ref)
    elif isinstance(ref, list):
        ref_word_lst = ref
    else:
        raise TypeError('type of ref should be str or list')

    if isinstance(hyp, str):
        hyp_word_lst, _, _ = wordize_and_map(hyp)
    elif isinstance(hyp, list):
        hyp_word_lst = hyp
    else:
        raise TypeError('type of hyp should be str or list')

    ref_word_lst = remove_mark(ref_word_lst)
    hyp_word_lst = remove_mark(hyp_word_lst)
    ref_word_lst = english_upper(ref_word_lst)
    hyp_word_lst = english_upper(hyp_word_lst)
    if bopomofo:
        ref_word_lst = _convert_to_bopomofo(ref_word_lst)
        hyp_word_lst = _convert_to_bopomofo(hyp_word_lst)
    if exec_detail:
        executions = editops(ref_lst=ref_word_lst, hyp_lst=hyp_word_lst)
        cer = len(executions) / len(ref_word_lst)
        return cer, executions
    else:
        _, cost_matrix = _create_opt_and_cost_matrix(
            ref_lst=ref_word_lst, hyp_lst=hyp_word_lst)
        cer = cost_matrix[-1][-1] / len(ref_word_lst)
        return cer


def ref_to_hyp_trans(ref_lst, executions):
    ref_lst = deepcopy(ref_lst)
    for exec_ind, exec_type, _, hyp in executions:
        if exec_type == 'subsitute':
            ref_lst[exec_ind] = hyp
        elif exec_type == 'insertion':
            ref_lst.insert(exec_ind, hyp)
        elif exec_type == 'deletion':
            ref_lst.pop(exec_ind)
    return ref_lst
