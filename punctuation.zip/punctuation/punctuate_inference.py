import logging
import re
from collections import defaultdict

import torch
from torch.utils.data import DataLoader
from tqdm import tqdm
from transformers import BertForTokenClassification, BertTokenizer

from punctuate import FORMAT, PUNCTUATIONS, TextDataset

logging.basicConfig(level=logging.DEBUG, format=FORMAT)


def _get_sentences(input_ids, infos, pred_labels_list, punctuations):
    new_sentences = []
    punct_indices = []
    for input_id, info, pred_labels in zip(input_ids, infos, pred_labels_list):
        new_sentence = info['text']
        tokens = info['tokens']
        token2text = info['token2text']
        input_id_list = input_id.cpu().tolist()
        pred_labels = pred_labels[1:input_id_list.index(102)]  # delete [CLS], [SEP]
        assert len(pred_labels) == len(token2text)

        # generate punct_index_map
        # (list of tuples be like: [(char_index, 'punctuation_str'), ...]
        punct_index_tuples = []
        token_pointer = 0
        while token_pointer < len(tokens):
            label = pred_labels[token_pointer]
            if label > 0:
                if token_pointer + 1 < len(tokens) and tokens[token_pointer + 1].startswith('##'):
                    while token_pointer + 1 < len(tokens):
                        if tokens[token_pointer + 1].startswith('##'):
                            token_pointer += 1
                        else:
                            break
                punct_index = token2text[token_pointer][1] - 1
                punct = punctuations[label - 1]
                punct_index_tuples.append((punct_index, punct))
            token_pointer += 1
        for punct_order_id, punct_index_tuple in enumerate(punct_index_tuples):
            token_ending_index = punct_index_tuple[0]
            punct_string = punct_index_tuple[1]
            insertion_index = token_ending_index + punct_order_id + 1
            new_sentence = new_sentence[:insertion_index] \
                            + punct_string + new_sentence[insertion_index:]
        new_sentences.append(new_sentence)
        punct_indices.append(punct_index_tuples)
    return new_sentences, punct_indices


def _cut_sentence_by_punctuation(text_with_punctuation, punct_index_tuples, punctuations):
    char_pointer = len(text_with_punctuation) - 1
    cutting_index = char_pointer
    left_text_without_punctuation = ''
    punct_cnt = 0

    while char_pointer >= 0:
        current_char = text_with_punctuation[char_pointer]
        if current_char in punctuations:
            punct_cnt += 1
            punct_index_tuples = punct_index_tuples[:-1]  # remove the last (index, punct) tuple
            if punct_cnt == 2:
                cutting_index = char_pointer + 1  # include the punctuation
                break
        else:
            left_text_without_punctuation = current_char + left_text_without_punctuation
        char_pointer -= 1
    partial_text_with_punctuation = text_with_punctuation[:cutting_index]
    return partial_text_with_punctuation, left_text_without_punctuation, punct_index_tuples


def _inference_single_batch(batch_data, model, device):
    input_ids, token_type_ids, attention_mask = [d.to(device) for d in batch_data[:3]]
    infos = batch_data[3]
    outputs = model(
        input_ids=input_ids,
        token_type_ids=token_type_ids,
        attention_mask=attention_mask,
    )  # model output is single-length tuple which contains torch.tensor
    pred_labels_list = torch.argmax(outputs.logits, dim=-1).cpu().tolist()
    pred_sentences, pred_punct_indices = _get_sentences(input_ids, infos, pred_labels_list, PUNCTUATIONS)
    return pred_sentences, pred_punct_indices


def load_model_and_tokenizer(device,
                             tokenizer_dir='/project/if-beautiful-text/shared/cache_dir/bert-base-chinese',
                             punct_model_dir='./models/punctuation/'):
    logging.info('Load bert tokenizer and punctuation model')
    tokenizer = BertTokenizer.from_pretrained(tokenizer_dir, map_location=device)
    model = BertForTokenClassification.from_pretrained(punct_model_dir, return_dict=True)
    model.to(device)
    model.eval()
    return tokenizer, model


def inference(inference_texts, tokenizer, model, device, inference_batch_size=4, max_inference_length=450):
    # for the model can only accept fixed length of input data,
    # use processing_index to store the index and running pointer of inference_texts
    # to help keeping track of the progress and concatenating prediction results.
    # e.g., if len(inference_texts[0]) == 800, processing_index = {0: 450},
    # which implies that inference_texts[0][450: 800] will be inserted in next iteration
    processing_index = {k: 0 for k, _ in enumerate(inference_texts)}
    pred_sentences_dict = defaultdict(str)
    pred_punct_indices_dict = defaultdict(list)

    while len(processing_index) > 0:
        input_sentences = []
        input_indices = []
        batch_indices = list(processing_index.keys())

        logging.info('Check and indexing oversized sentences')
        for idx in batch_indices:
            starting_index = processing_index[idx]
            ending_index = starting_index + max_inference_length
            sentence = inference_texts[idx][starting_index:ending_index]
            input_sentences.append(sentence)
            if ending_index >= len(inference_texts[idx]):
                del processing_index[idx]
            else:
                processing_index[idx] += len(sentence)
            input_indices.append(idx)

        logging.info('Data transformation for model inference')
        inference_dataset = TextDataset(tokenizer, input_sentences, PUNCTUATIONS, for_train=False)
        inference_loader = DataLoader(
            dataset=inference_dataset,
            batch_size=inference_batch_size,
            collate_fn=inference_dataset.create_mini_batch)

        logging.info('Prediction starts...')
        pred_sentences_list = []
        pred_punct_indices_batch = []
        oversized_text_ids = processing_index.keys()

        with torch.no_grad():
            for inference_data in tqdm(inference_loader, desc='evaluate'):
                pred_sentences, pred_punct_indices = _inference_single_batch(inference_data, model, device)
                pred_sentences_list += pred_sentences
                pred_punct_indices_batch += pred_punct_indices
            for input_id, pred_sentence, pred_punct_indices in zip(
                 input_indices, pred_sentences_list, pred_punct_indices_batch):
                # keep the length of current processed sentence to align the global punctuation index
                partial_raw_input = re.sub(r'[，。、！？]', r'', pred_sentences_dict[input_id])
                if input_id in oversized_text_ids:
                    partial_result, left_result_without_punctuation, pred_punct_indices = \
                        _cut_sentence_by_punctuation(pred_sentence, pred_punct_indices, PUNCTUATIONS)
                    pred_sentences_dict[input_id] += partial_result
                    processing_index[input_id] -= len(left_result_without_punctuation)
                else:
                    pred_sentences_dict[input_id] += pred_sentence
                # align the local punctuation index to global paragraph index
                if len(partial_raw_input) > 0:
                    pred_punct_indices = [(i + len(partial_raw_input), j) for i, j in pred_punct_indices]
                pred_punct_indices_dict[input_id] += pred_punct_indices
    concated_pred_sentences = []
    concated_pred_punct_indices = []
    for idx, _ in enumerate(inference_texts):
        concated_pred_sentences.append(pred_sentences_dict[idx])
        concated_pred_punct_indices.append(pred_punct_indices_dict[idx])
    return concated_pred_sentences, concated_pred_punct_indices


if __name__ == '__main__':
    device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
    logging.info(f'device: {device}')
    tokenizer, model = load_model_and_tokenizer(device)

    logging.info('Load text data without punctuations')
    # Replace your data
    data = [
            '清朝末年洋務運動戊戌變法等自上而下改革以及義和團運動的失敗使得很多中國人相信只有通過徹底的革命廢除掉舊有的制度和體制並建立新的制度和體制才是有效的方法這個革命的領導人孫中山一個反清的共和主義者開始在海外華人留學生特別是日本的留學生間受到矚目1905年7月30日孫中山在日本東京召開中國同盟會籌備會議他在中國同盟會盟書中提出驅除韃虜恢復中華創立民國平均地權的同盟會綱領並為未來實現共和制度的中國取中華民國的國號孫中山和另一個同樣受到矚目的中國革命領袖黃興建立中國同盟會中國國內的一些地區軍閥百日維新後流亡海外的改革派以及海外的華人對這個運動給以大量的資金支持孫中山的政治理念在1897年形成1905年首次在東京發表並在1920年代早期作過一些修改他的理論集中在三民主義民族民權民生民族主義號召人民推翻滿族的統治以及結束外國霸權在中國的勢力民權表達孫中山期望建立一個普選的共和政府的理想民生通常被描述成為社會主義是指通過對生產方式所有制的規範來幫助平民1911年清廷爲了控制保路運動將部分湖北新軍調往四川使得武昌防守空虛革命黨人黃興利用這個機會打算在10月底發動一場起義10月9日反清的革命計劃被暴露由革命黨人組成的新軍被逼提前起義這就是武昌起義也是中華民國國慶雙十節的來源武昌起義成功後第二天中華民國軍政府鄂軍都督府於1911年10月11日在湖北武昌成立這是中華民國第一個省級軍政府同時代行中央軍政府之職責起義發動者臨時推舉清軍第二十一混成協協統黎元洪出任中華民國軍政府鄂軍都督府都督改湖北省諮議局大樓為都督府並根據孫中山編定的革命方略的原則精神宣布廢除清朝宣統年號改國號為中華民國',
            '數學的專業化主要的分歧為純數學和應用數學在應用數學內又被分成兩大領域並且變成了它們自身的學科——統計學和computer science每當有涉及數量結構空間及變化等方面的困難問題時通常就需要用到數學工具去解決問題而這往往也拓展了數學的研究範疇空軍退役中校杜永心被中共中央軍事委員會政治工作部吸收以贈送現金酒茶葉提議招待出國旅遊等方式拉攏我國蔡姓陸軍現役中校警察局長劉柏良強調對於聚眾鬥毆街頭暴力零容忍除查緝涉案人外也會向上溯源刨根斷源不僅要打擊街頭暴力也要杜絕一切可能演變成街頭暴力的誘因和工具'
           ]
    pred_sentences, pred_punct_indices = inference(data, tokenizer, model, device)
