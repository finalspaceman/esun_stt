import re


def wordize_and_map(text):
    words = []
    index_map_from_text_to_word = []
    index_map_from_word_to_text = []
    while len(text) > 0:
        match_space = re.match(r'^ +', text)
        if match_space:
            space_str = match_space.group(0)
            index_map_from_text_to_word += [None] * len(space_str)
            text = text[len(space_str):]
            continue

        match_en = re.match(r'^[a-zA-Z0-9]+', text)
        if match_en:
            en_word = match_en.group(0)

            word_start_pos = len(index_map_from_text_to_word)
            word_end_pos = word_start_pos + len(en_word)
            index_map_from_word_to_text.append((word_start_pos, word_end_pos))

            index_map_from_text_to_word += [len(words)] * len(en_word)

            words.append(en_word)
            text = text[len(en_word):]
        else:
            word_start_pos = len(index_map_from_text_to_word)
            word_end_pos = word_start_pos + 1
            index_map_from_word_to_text.append((word_start_pos, word_end_pos))

            index_map_from_text_to_word += [len(words)]

            words.append(text[0])
            text = text[1:]
    return words, index_map_from_text_to_word, index_map_from_word_to_text


def tokenize_and_map(tokenizer, text):
    words, text2word, word2text = wordize_and_map(text)

    tokens = []
    index_map_from_token_to_text = []
    for word, (word_start, word_end) in zip(words, word2text):
        word_tokens = tokenizer.tokenize(word)

        if len(word_tokens) == 0 or word_tokens == ['[UNK]']:
            index_map_from_token_to_text.append((word_start, word_end))
            tokens.append('[UNK]')
        else:
            current_word_start = word_start
            for word_token in word_tokens:
                word_token_len = len(re.sub(r'^##', '', word_token))
                index_map_from_token_to_text.append(
                    (current_word_start, current_word_start + word_token_len))
                current_word_start = current_word_start + word_token_len
                tokens.append(word_token)

    index_map_from_text_to_token = text2word
    for i, (token_start, token_end) in enumerate(index_map_from_token_to_text):
        for token_pos in range(token_start, token_end):
            index_map_from_text_to_token[token_pos] = i

    return tokens, index_map_from_text_to_token, index_map_from_token_to_text


class RunningAverage:
    def __init__(self):
        self.values = []

    def add(self, val):
        self.values.append(val)

    def add_all(self, vals):
        self.values += vals

    def get(self):
        return sum(self.values) / len(self.values)

    def flush(self):
        self.values = []


def get_zero_confusion_matrix():
    return {
        'sentence_level': {
            'detect': {
                'TP': 0, 'FP': 0, 'FN': 0
            },
            'correct': {
                'TP': 0, 'FP': 0, 'FN': 0
            },
        },
        'character_level': {
            'detect': {
                'TP': 0, 'FP': 0, 'FN': 0
            },
            'correct': {
                'TP': 0, 'FP': 0, 'FN': 0
            },
        },
    }


def accumlate_confusion_matrix(confusion_matrix, true_positions, pred_positions, true_pairs, pred_pairs):
    # sentence level detect
    if true_positions == pred_positions:
        if len(pred_positions) > 0:
            confusion_matrix['sentence_level']['detect']['TP'] += 1
    else:
        if len(pred_positions) > 0:
            confusion_matrix['sentence_level']['detect']['FP'] += 1
        if len(true_positions) > 0:
            confusion_matrix['sentence_level']['detect']['FN'] += 1
    
    # sentence level correct
    if true_pairs == pred_pairs:
        if len(pred_pairs) > 0:
            confusion_matrix['sentence_level']['correct']['TP'] += 1
    else:
        if len(pred_pairs) > 0:
            confusion_matrix['sentence_level']['correct']['FP'] += 1
        if len(true_pairs) > 0:
            confusion_matrix['sentence_level']['correct']['FN'] += 1

    # character level detect
    true_positive_positions = true_positions & pred_positions
    confusion_matrix['character_level']['detect']['TP'] += len(true_positive_positions)
    confusion_matrix['character_level']['detect']['FP'] += len(pred_positions - true_positive_positions)
    confusion_matrix['character_level']['detect']['FN'] += len(true_positions - true_positive_positions)
    
    # character level correct
    pred_pairs_with_only_detect_true = set()
    for position, char in pred_pairs:
        if position in true_positive_positions:
            pred_pairs_with_only_detect_true.add((position, char))
    true_positive_pairs = true_pairs & pred_pairs_with_only_detect_true
    confusion_matrix['character_level']['correct']['TP'] += len(true_positive_pairs)
    confusion_matrix['character_level']['correct']['FP'] += len(pred_pairs_with_only_detect_true - true_positive_pairs)
    confusion_matrix['character_level']['correct']['FN'] += len(true_pairs - true_positive_pairs)


def get_csc_confusion_matrix_at_e2e(input_ids, labels, preds, skip_token_ids, init_confusion_matrix=None):
    if init_confusion_matrix is None:
        confusion_matrix = get_zero_confusion_matrix()
    else:
        confusion_matrix = init_confusion_matrix

    for token_id_list, label_list, pred_list in zip(input_ids, labels, preds):
        true_positions, pred_positions, true_pairs, pred_pairs = set(), set(), set(), set()
        for i, (token_id, label, pred) in enumerate(zip(token_id_list, label_list, pred_list)):
            if token_id in skip_token_ids:
                continue
            if token_id != label:
                true_positions.add(i)
                true_pairs.add((i, label))
            if token_id != pred:
                pred_positions.add(i)
                pred_pairs.add((i, pred))

        accumlate_confusion_matrix(confusion_matrix, true_positions, pred_positions, true_pairs, pred_pairs)

    return confusion_matrix


def get_csc_metric(confusion_matrix):
    evaluation = {}
    for level, level_values in confusion_matrix.items():
        for stage, values in level_values.items():
            metric_prefix = '{}_{}_'.format(
                'sent' if level == 'sentence_level' else 'char',
                stage,
            )
            try:
                precision = values['TP'] / (values['TP'] + values['FP'])
            except ZeroDivisionError:
                precision = None

            try:
                recall = values['TP'] / (values['TP'] + values['FN'])
            except ZeroDivisionError:
                recall = None

            if precision is None or recall is None:
                f1 = None
            else:
                try:
                    f1 = 2 / (1 / precision + 1 / recall)
                except ZeroDivisionError:
                    f1 = None

            evaluation[metric_prefix + 'precision'] = precision
            evaluation[metric_prefix + 'recall'] = recall
            evaluation[metric_prefix + 'f1'] = f1
    return evaluation
