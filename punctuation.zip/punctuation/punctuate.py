import os
import logging
from collections import defaultdict
import time

import torch
import torch.optim as optim
from torch import Tensor
from torch.utils.data import Dataset, DataLoader
from torch.nn.utils.rnn import pad_sequence
from transformers import BertTokenizer, BertForTokenClassification
import numpy as np
from tqdm import tqdm

from evaluation_func import calculate_f1, extract_punctuation_map
from utils import tokenize_and_map

SPECIAL_TOKENS = ['[CLS]', '[SEP]', '[PAD]']
PUNCTUATIONS = '，。、！？'
FORMAT = '%(asctime)s %(levelname)s: %(message)s'
logging.basicConfig(level=logging.DEBUG, format=FORMAT)


class TextDataset(Dataset):
    def __init__(self, tokenizer, texts, punctuations, punct_maps=None,
                 pad_token_label_id=0, max_length=512, for_train=True):
        self.tokenizer = tokenizer
        self.pad_token_label_id = pad_token_label_id
        self.texts = texts
        self.punctuations = punctuations
        self.max_length = max_length
        self.punct_maps = punct_maps
        self.for_train = for_train

    def __getitem__(self, idx):
        text = self.texts[idx]
        tokens, text2token, token2text = tokenize_and_map(self.tokenizer, text)

        cut_index = self.max_length - 2
        if cut_index < len(tokens):
            cut_text_index = text2token.index(cut_index)
            tokens = tokens[:cut_index]
            text = text[:cut_text_index]
            text2token = text2token[:cut_text_index]
            token2text = token2text[:cut_index]

        processed_tokens = ['[CLS]'] + tokens + ['[SEP]']

        input_ids = torch.tensor(self.tokenizer.convert_tokens_to_ids(processed_tokens))
        token_type_ids = torch.tensor([0] * len(processed_tokens))
        attention_mask = torch.tensor([1] * len(processed_tokens))

        outputs = (input_ids, token_type_ids, attention_mask, )

        if self.for_train:
            punct_map = self.punct_maps[idx]

            labels = []

            for i, token_index in enumerate(text2token):
                if token_index is None:
                    continue
                if token_index >= len(labels):
                    if i in punct_map:
                        punct = punct_map[i][0]  # only select one here
                        labels.append(1 + self.punctuations.index(punct))
                    else:
                        labels.append(0)  # no punctuation


            labels = torch.tensor(
                [self.pad_token_label_id] + labels + [self.pad_token_label_id]
                # for [CLS] and [SEP]
            )

            if input_ids.size(0) != labels.size(0) or labels.size(0) > self.max_length:
                logging.warn(f'Drop sentence "{text}"')
                return self[(idx + 1) % len(self)]
            outputs += (labels, )

        info = {
            'tokens': tokens,
            'text': text,
            'text2token': text2token,
            'token2text': token2text
        }
        outputs += (info, )
        return outputs

    def __len__(self):
        return len(self.texts)


    def create_mini_batch(self, samples):
        outputs = list(zip(*samples))

        # zero pad 到同一序列長度
        input_ids = pad_sequence(outputs[0], batch_first=True)
        token_type_ids = pad_sequence(outputs[1], batch_first=True)
        attention_mask = pad_sequence(outputs[2], batch_first=True)

        batch_output = (input_ids, token_type_ids, attention_mask)
    
        if self.for_train:
            labels = pad_sequence(outputs[3], batch_first=True)
            batch_output += (labels, )
        else:
            infos = outputs[3]
            batch_output += (infos, )
        return batch_output


def train_batch(model, data, optimizer, device):
    model.train()

    input_ids, token_type_ids, attention_mask, labels = [d.to(device) for d in data]

    outputs = model(
        input_ids=input_ids,
        token_type_ids=token_type_ids,
        attention_mask=attention_mask,
        labels=labels
    )
    loss = outputs.loss

    optimizer.zero_grad()
    loss.backward()
    optimizer.step()
    return loss.item()        
    

def _get_punctuation_maps(input_ids, labels, tokenizer, punctuations):
    punct_maps = []
    tokens_list = []
    for input_id_list, label_list in zip(input_ids, labels):
        token_list = tokenizer.convert_ids_to_tokens(input_id_list)
        punct_map = {}
        tokens = []
        word_count = 0
        for token, label in zip(token_list, label_list):
            if token in SPECIAL_TOKENS:
                continue
            if label > 0:
                punct_map[word_count] = [punctuations[label - 1]]
            tokens.append(token)
            word_count += 1
        punct_maps.append(punct_map)
        tokens_list.append(tokens)
    return punct_maps, tokens_list


def _get_shown_case(punct_map, tokens):
    new_tokens = []
    for i, token in enumerate(tokens):
        new_tokens.append(token)
        if i in punct_map:
            new_tokens.append(punct_map[i][0])
    return ' '.join(new_tokens)


def evaluate(model, valid_loader, tokenizer):
    model.eval()
    device = 'cuda' if next(model.parameters()).is_cuda else 'cpu'

    tot_count = 0
    tot_loss = 0
    precision_dict = defaultdict(list)
    recall_dict = defaultdict(list)
    f1_dict = defaultdict(list)

    with torch.no_grad():
        for data in tqdm(valid_loader, desc='evaluate'):
            input_ids, token_type_ids, attention_mask, labels = [d.to(device) for d in data]

            outputs = model(
                input_ids=input_ids,
                token_type_ids=token_type_ids,
                attention_mask=attention_mask,
                labels=labels
            )

            input_ids_list = input_ids.cpu().tolist()
            true_punct_maps, true_tokens_list = _get_punctuation_maps(
                input_ids_list, 
                labels.cpu().tolist(),
                tokenizer,
                PUNCTUATIONS)
            pred_punct_maps, pred_tokens_list = _get_punctuation_maps(
                input_ids_list, 
                outputs.logits.argmax(dim=-1).cpu().tolist(),
                tokenizer,
                PUNCTUATIONS)

            for true_punct_map, pred_punct_map in zip(true_punct_maps, pred_punct_maps):
                precision, recall, f1 = calculate_f1(true_punct_map, pred_punct_map, PUNCTUATIONS)
                for punct in PUNCTUATIONS:
                    precision_dict[punct].append(precision[punct])
                    recall_dict[punct].append(recall[punct])
                    f1_dict[punct].append(f1[punct])

            tot_count += input_ids.size(0)
            tot_loss += outputs.loss.item()
    
    true_case = _get_shown_case(true_punct_maps[0], true_tokens_list[0])
    pred_case = _get_shown_case(pred_punct_maps[0], pred_tokens_list[0])
    logging.info('example:\ntrue: "{}"\npred: "{}"\n'.format(true_case, pred_case))
    
    def averge_excluding_none(li):
        li = [e for e in li if e]
        return np.mean(li)

    averge_precision = {punct: averge_excluding_none(precision_dict[punct]) for punct in PUNCTUATIONS}
    averge_recall = {punct: averge_excluding_none(recall_dict[punct]) for punct in PUNCTUATIONS}
    averge_f1 = {punct: averge_excluding_none(f1_dict[punct]) for punct in PUNCTUATIONS}
    evaluation = {
        'loss': tot_loss / tot_count,
        'averge_precision': averge_precision,
        'averge_recall': averge_recall,
        'averge_f1': averge_f1
    }
    return evaluation


def bert_main(train_texts, valid_texts,
              model_dir='/project/if-beautiful-text/shared/cache_dir/bert-base-chinese',
              save_dir='./models/punctuation/'):
    lr = 0.00001
    train_batch_size = 16
    evaluate_batch_size = 128
    max_iter = 100000
    show_train_per_iter = 100
    show_eval_per_iter = 500
    save_per_iter = 1000
    cpu_workers = 4
    checkpoint_folder = None

    assert save_per_iter % show_eval_per_iter == 0

    device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
    logging.info(f'device: {device}')

    tokenizer = BertTokenizer.from_pretrained(model_dir)

    if not checkpoint_folder:
        model = BertForTokenClassification.from_pretrained(
            model_dir, 
            return_dict=True,
            num_labels=len(PUNCTUATIONS)+1)
    else:
        model = BertForTokenClassification.from_pretrained(checkpoint_folder)

    model.to(device)

    train_punct_map, train_texts_without_punct = \
        extract_punctuation_map(train_texts, PUNCTUATIONS)
    valid_punct_map, valid_texts_without_punct = \
        extract_punctuation_map(valid_texts, PUNCTUATIONS)

    train_dataset = TextDataset(tokenizer, train_texts_without_punct, PUNCTUATIONS, train_punct_map)
    valid_dataset = TextDataset(tokenizer, valid_texts_without_punct, PUNCTUATIONS, valid_punct_map)

    train_loader = DataLoader(
        dataset=train_dataset,
        batch_size=train_batch_size,
        collate_fn=train_dataset.create_mini_batch,
        shuffle=True,
        num_workers=cpu_workers)
    valid_loader = DataLoader(
        dataset=valid_dataset,
        batch_size=evaluate_batch_size,
        collate_fn=valid_dataset.create_mini_batch,
        shuffle=True,
        num_workers=cpu_workers)

    optimizer = optim.Adam(model.parameters(), lr=lr)
    scheduler = optim.lr_scheduler.StepLR(optimizer, step_size=2, gamma=0.1)

    i = 1
    is_running = True
    while is_running:
        for train_data in train_loader:
            loss = train_batch(model, train_data, optimizer, device)
            train_size = train_data[0].size(0)

            if i % show_train_per_iter == 0:
                logging.info('train_loss [{iter}]: {train_loss}'.format(
                    iter=i, train_loss=loss/train_size))

            if i % show_eval_per_iter == 0:
                evaluation = evaluate(model, valid_loader, tokenizer)
                logging.info('valid_evaluation: loss={loss},\n precision=\n{averge_precision}\n'
                             'recall=\n{averge_recall}\nf1=\n{averge_f1}\n'
                             .format(**evaluation))

            if i % save_per_iter == 0:
                eval_loss = evaluation['loss']
                path = os.path.join(save_dir, f'punct_model_step{i}_loss{eval_loss}/')
                logging.info(f'Save model at {path}')
                model.save_pretrained(path)

            if i == max_iter:
                is_running = False
                break
            i += 1

        scheduler.step()


if __name__ == '__main__':
    logging.info('Load training/validation dataset ...')

    with open('/project/if-beautiful-text/shared/datasets/wiki_punctuation_data/wiki_with_punctuation_train.txt') as f:
        train_texts = []
        for line in f:
            if len(line) < 500:
                train_texts.append(line.strip())        
    
    with open('/project/if-beautiful-text/shared/datasets/wiki_punctuation_data/wiki_with_punctuation_valid.txt') as f:
        valid_texts = []
        for line in f:
            if len(line) < 500:
                valid_texts.append(line.strip())    
    
    logging.info('Start training ...')
    bert_main(train_texts=train_texts, valid_texts=valid_texts)
