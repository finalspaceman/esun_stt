import re
import json
import os
import sys

SRC_DIR = os.path.abspath(os.path.dirname(os.path.dirname(__file__)))
sys.path.insert(0, SRC_DIR)

import pandas as pd
from tqdm import tqdm

from utils import wordize_and_map
from evaluation_func import editops, remove_mark, english_upper


def _wordize_from_asr(sentence):
    raw_str_list = sentence.split()
    rst_str_list = []
    non_chinese_reg = r'[^\u4E00-\u9FFF]+'
    for raw_char in raw_str_list:
        if re.match(non_chinese_reg, raw_char):
            rst_str_list.append(raw_char)
        else:
            rst_str_list += [char for char in raw_char]  # split chinese chuck
    return rst_str_list

def _wordize(sentence, mode):
    if mode == 'asr':
        word_lst = _wordize_from_asr(sentence)
    elif mode == 'ref':
        word_lst, _ = wordize_and_map(sentence)
    else:
        raise ValueError('mode must be asr or ref')
    word_lst = remove_mark(word_lst)
    word_lst = english_upper(word_lst)
    return word_lst

def main(file_name):
    asr_path = f'./{file_name}/decode_txt.csv'
    ref_path = f'./{file_name}.csv'
    alignment_path = f'./{file_name}'+'/phone_ali/{num}_phoneAli.txt'
    output_path = f'../confuse_dataset/{file_name}_confuse_dataset.tsv'
    
    df_asr = pd.read_csv(asr_path, header=None)
    df_asr.columns = ['wav_path', 'asr_sentence']

    df_ref = pd.read_csv(ref_path, header=None)
    df_ref = df_ref.iloc[:len(df_asr), :]
    df_ref.columns = ['ref_sentence']

    df = pd.concat([df_asr, df_ref], axis=1)

    asr_words = [_wordize(sentence, mode='asr') for sentence in df.loc[:, 'asr_sentence']]
    ref_words = [_wordize(sentence, mode='ref') for sentence in df.loc[:, 'ref_sentence']]
    df['asr_words'] = asr_words
    df['ref_words'] = ref_words
    df.drop(['asr_sentence', 'ref_sentence'], axis=1, inplace=True)
    
    def create_phoneme_path(wav_path):
        wav_name = (os.path.splitext(wav_path)[-2])[-5:]
        return os.path.abspath(alignment_path.format(num=wav_name))

    df['phoneme_path'] = df['wav_path'].apply(create_phoneme_path)

    def create_wrong_detail(row):
        ref_sentence = row['ref_words']
        asr_sentence = row['asr_words']
        wrong_detail = editops(ref_sentence, asr_sentence)
        return json.dumps(wrong_detail)

    df['wrong_detail'] = df.apply(create_wrong_detail, axis=1)

    df.to_csv(output_path, sep='\t', index=False)


if __name__ == "__main__":
    file_name = 'Cheng_F'

    main(file_name)