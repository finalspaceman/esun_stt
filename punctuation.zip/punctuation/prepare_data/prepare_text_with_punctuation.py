import glob
import re
import random
import logging

from opencc import OpenCC


FORMAT = '%(asctime)s %(levelname)s: %(message)s'
logging.basicConfig(level=logging.DEBUG, format=FORMAT)


def main():
    cc = OpenCC('s2t')
    valid_size = 100000
    test_size = 200000
        
    f_valid = open('data/wiki_with_punctuation_valid.txt', 'w')
    f_test = open('data/wiki_with_punctuation_test.txt', 'w')
    f_train = open('data/wiki_with_punctuation_train.txt', 'w')

    sentences = []
    count = 0
    tags = [f'A{c}' for c in 'ABCDEFGHIJKLMNO']
    for tag in tags:
        for txt_file in glob.glob(f'./text/{tag}/*'):
            for line in open(txt_file).readlines():
                line = line.strip()
                if len(line) < 20:
                    continue
                if line.startswith('<doc id='):
                    continue
                line = cc.convert(line)
                #line = re.sub(r'\s+', '', line)
                line = re.sub(r'（.*）', '', line)
                line = re.sub(r'\(.*\)', '', line)
                line = re.sub(r'[`《》·‘’“”「」"{}【】［］『』〈〉\[\]]', '', line)
                line = re.sub(r'[％%]', '趴', line)
                line = re.sub(r'!', '！', line)
                line = re.sub(r'\?', '？', line)
                line = re.sub(r'[.;；]', '。', line)
                line = re.sub(r'[\,:：]', '，', line)                                      
                line = re.sub(r'([0-9])[。，、？！]([0-9])', r'\1\2', line)
                
                if len(line) < 5:
                    continue
                non_accord_pattern = r'[^\u4E00-\u9FFF。，、？！a-zA-Z0-9]+'
                if re.search(non_accord_pattern, line):
                    continue
                if re.search(r'[。，、？！][。，、？！]+', line):
                    continue
                    
                sentences.append(line + '\n')
                
                count += 1
                if count % 10000 == 0:
                    logging.info('Already process {count} sentences'.format(count=count))

    random.shuffle(sentences)

    for i in range(len(sentences)):
        if i < valid_size:
            f_valid.write(sentences[i])
        elif i < (test_size + valid_size):
            f_test.write(sentences[i])
        else:
            f_train.write(sentences[i])
    
    for open_file in [f_valid, f_test, f_train]:
        open_file.close()
                    
                    
if __name__ == '__main__':
    main()