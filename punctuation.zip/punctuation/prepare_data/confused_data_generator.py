import re
import os
import sys
import json
import random

import regex
import jieba
from tqdm import tqdm
from transformers import BertTokenizer

SRC_DIR = os.path.abspath(os.path.dirname(os.path.dirname(__file__)))
sys.path.insert(0, SRC_DIR)
import config
from evaluation_func import calculate_cer

SAVE_PATH = 'wiki_formask_train_word_1.json'
SPEC_WORD = '犇'   # 用以覆蓋原文的特殊字


class ConfusedDataGenerator():
    def __init__(self, texts, mode='char', typo_amount=1, typo_gap=0, typo_format=None,  random_state=13):
        """
        mode: 'char'是以「字」為單位進行遮罩；'word'是以「斷詞」為單位進行遮罩
        """
        self.texts = texts
        self.mode = mode
        self.typo_amount = typo_amount
        self.typo_gap = typo_gap   # count of origin word between typo words
        self.typo_format = typo_format    # personalize the typo's type (0 = 保留原字 / 2 = 要修改文字)
        self.random_state = random_state

    def _get_random_word(self):
        # 基於GBK2312編碼，包含6000多個常用漢字
        head = random.randint(0xb0, 0xf7)
        body = random.randint(0xa1, 0xfe)
        val = f'{head:x}{body:x}'
        random_word = self.cc.convert(bytes.fromhex(val).decode('gb2312'))
        return random_word
    
    def _search_not_ch(self, char):
        return re.search(r'[^\u4e00-\u9fa5]', char)

    def _get_changeable_state(self):
        if self.typo_format:
            typo_format = self.typo_format
        else:
            a, g = self.typo_amount, self.typo_gap
            typo_format = '2'
            while a > 1:
                typo_format += ('0' * g) + '2'
                a -= 1
        changeable_state_format = '1' * len(typo_format) 
        changeable_state = regex.compile(changeable_state_format)   # prepare for regex.finditer
        return typo_format, changeable_state

    def generate_confuse_texts(self):
        assert self.mode in ['char', 'word'], "mode should be 'char' or 'word'"
        typo_format, changeable_state = self._get_changeable_state()

        processed_texts = []
        for text in tqdm(self.texts):
            if self.mode == 'word':
                text = [i for i in jieba.cut(text)]
            
            # Init state
            """
            [state說明] 0 = 非中文or保留原字 / 1 = 可變動文字 / 2 = 要修改文字
            1. e.g. '玉山提升AI技術' -> text_state='11110011'
            2. 若要兩個錯字間隔一格 -> typo_format='202' / changeable_state_format='111'
            """
            text_state = \
                ''.join(['0' if self._search_not_ch(char) else '1' for char in text]) 
            changeable_positions = \
                [p.start() for p in regex.finditer(changeable_state, text_state, overlapped=True)]
            
            if not changeable_positions:
                processed_texts.append(text)
                print(f'未進行更動: {text}')
                continue
            change_position = random.sample(changeable_positions, k=1)[0]
            
            # Update state
            text_state = text_state[:change_position] \
                         + typo_format + text_state[change_position+len(typo_format):]                

            processed_text = ''
            for word, state in zip(text, text_state):
                if state == '2':
                    processed_text += SPEC_WORD * len(word)  # 保留可生成隨機漢字功能: _get_random_word()
                else:
                    processed_text += word
            processed_texts.append(processed_text)
        return processed_texts


def save_data(texts, processed_texts):
    tokenizer = BertTokenizer.from_pretrained(config.BERT_PATH)
    with open(SAVE_PATH, 'w') as fw:
        for text, processed_text in zip(texts, processed_texts):
            typos = [(SPEC_WORD, text[i], i) for i, char in enumerate(processed_text) if char == SPEC_WORD]
            if typos:
                tmp = {'text': processed_text, 'typo': typos}
                fw.write(f'{json.dumps(tmp)}\n')


if __name__ == "__main__":
    with open(config.WIKI_TRAIN_PATH, 'r') as fr:
        texts = fr.readlines()
    texts = [text.strip('\n') for text in texts]
    confuse_generator = ConfusedDataGenerator(texts, mode='char')
    processed_texts = confuse_generator.generate_confuse_texts()
    save_data(texts, processed_texts)
