import glob
import re

from opencc import OpenCC


class NumberChineseMapper:
    directed_mapping = {
        '1': '一',
        '2': '二',
        '3': '三',
        '4': '四',
        '5': '五',
        '6': '六',
        '7': '七',
        '8': '八',
        '9': '九',
        '0': '零',
    }
    unit_base = {
        0: '',
        1: '十',
        2: '百',
        3: '千',
    }
    unit_second = {
        0: '',
        1: '萬',
        2: '億',
        3: '兆',
        4: '京',
    }

    @staticmethod
    def map_year(s):
        if len(s) == 5:
            return NumberChineseMapper.direct_map(s[:-1]) + s[-1]
        else:
            return NumberChineseMapper.unit_map(s[:-1]) + s[-1]

    @staticmethod
    def map_normal(s):
        s = s.replace(',', '')
        if len(s) > 4 * 4:
            return s 
        if '.' in s:
            before_point, after_point = s.split('.')
            before_point = NumberChineseMapper.unit_map(before_point)
            after_point = NumberChineseMapper.direct_map(after_point)
            return before_point + '點' + after_point
        else:
            return NumberChineseMapper.unit_map(s)
    
    @staticmethod
    def direct_map(s):
        return ''.join([NumberChineseMapper.directed_mapping[c] for c in s])

    @staticmethod
    def unit_map(s):
        if s == '0':
            return NumberChineseMapper.directed_mapping['0']

        is_positive = True
        num = [c for c in s]

        result = ''
        if num[0] == '-':
            is_positive = False
            num = num[1:]

        num = num[::-1]
        for i, c in enumerate(num):
            if i % 4 > 0 and c != '0':
                result = NumberChineseMapper.unit_base[i % 4] + result
            elif i % 4 == 0:
                result = NumberChineseMapper.unit_second[i // 4] + result

            if c == '1' and i % 4 == 1:
                continue
            if c != '0' or (i >= 1 and num[i - 1] != '0'):
                result = NumberChineseMapper.directed_mapping[c] + result

        return result if is_positive else '負' + result


def main():
    cc = OpenCC('s2t')
    path_fmt = 'data/{tag}.txt'

    tags = [f'A{c}' for c in 'ABCDEFGHIJKLMNO']
    for tag in tags:
        with open(path_fmt.format(tag=tag), 'w') as fw:
            for txt_file in glob.glob(f'./text/{tag}/*'):
                for line in open(txt_file).readlines():
                    line = line.strip()
                    if len(line) < 20:
                        continue
                    if line.startswith('<doc id='):
                        continue
                    if re.search(r'[a-zA-Z]', line):
                        continue
                    line = cc.convert(line)
                    line = re.sub(r'\s+', '', line)
                    line = re.sub(r'（.*）', '', line)
                    line = re.sub(r'\(.*\)', '', line)
                    line = re.sub(r'[《》“”「」"{}『』〈〉\[\]]', '', line)
                    line = re.sub(r'[％%]', '趴', line)
                    line = re.sub(r'[0-9]+年', lambda x: NumberChineseMapper.map_year(x.group()), line)
                    line = re.sub(r'[0-9]+[0-9,]*\.?[0-9]*',
                                lambda x: NumberChineseMapper.map_normal(x.group()), line)
                    line = re.sub(r'[,；]', '，', line)
                    line = line.replace(':', '：')
                    line = line.replace('！', '。')

                    line = re.sub(r'[，。？]', '\n', line)
                    for subline in line.split('\n'):
                        if len(subline) < 5:
                            continue

                        non_chinese_pattern = r'[^\u4E00-\u9FFF：、]+'
                        if re.search(non_chinese_pattern, subline):
                            continue

                        fw.write(subline + '\n')


if __name__ == '__main__':
    main()
